/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab3p1_jeffrimidence;

import java.util.Scanner;

/**
 *
 * @author sabdi
 */
public class Lab3p1_JeffriMidence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner (System.in);
        boolean sal= true;
                while (sal) {//inicio del while
                    System.out.println("BIENVENIDOS AL 3cer LABORATORIO");
                    System.out.println(" ");
                    System.out.println("1. Serie Euclidiana");
                    System.out.println("2. Pokebola");
                    System.out.println("3. OK Boomer");
                    System.out.println("4. Salir del programa");
                    int opcion = sc.nextInt();
                    
                    switch (opcion){//inicio del switch
                        case 1:
                            System.out.println("Ingrese el valor de 'N'");
                            int n = sc.nextInt();
                            double resultado = 0.0;
                            double resultado_2 = 0.0;
                            for (int i=1;i<=n;i++){//inicio del for
                                System.out.println("ingrese el valor de 'X'");
                                int x = sc.nextInt();
                                System.out.println("ingrese el valor de 'Y'");
                                int y = sc.nextInt();
                                
                                resultado = x-y;
                                resultado_2 += Math.pow(resultado,2);
                            }//fin del for
                            resultado_2 = Math.sqrt(resultado_2);
                            System.out.println("resultado= "+resultado_2);
                            
                            break;
                        case 2:
                            System.out.println("Ingrese el tama!o de la pokebola");
                            int poke = sc.nextInt();
                            
                            for (int i = 1; i<=poke;i++){//inicio del for externo
                                for(int k = 1;k<=(poke*2)-1;k++){//inicio del for 
                                    if (i==1 || i==poke || k==1 || k==poke*2-1 ){
                                        System.out.print("*");
                                    }
                                    else if (i==(poke/2)+1){//inicio de else if
                                        if (k>=poke*2/3 && k<=(poke*2)*2/3)
                                        System.out.print("#");
                                    }//fin del else if
                                    else if (i==(poke/2)+1){//inicio del else if 
                                        System.out.print("#");
                                    }
                                    else{
                                        System.out.print(" ");
                                    }//fin del else
                                }//inicio del for interno
                                System.out.println(" ");
                            }//fin del for externo
                            System.out.println(" ");
                            break;
                        case 3:
                            System.out.println("Ingrese su año de nacimiento: ");
                            int cumple = sc.nextInt();
                            
                            if (cumple >=1946 && cumple <=1964){//inicio del IF
                                System.out.println("FECILICIDADES USTED ES DE LA GENERACION BABY BOOMER GEN");
                            }//fin del IF
                            
                            else if  (cumple >=1960 && cumple <=1974){//inicio del if
                                System.out.println("FELICIDADES USTED ES DE LA GENERACION 'X'");
                            }//fin del if
                            
                            else if  (cumple >= 1975 && cumple <= 1985 ){//inicio del if
                                System.out.println("FELICIDADES USTED ES DE LA GENERACION XENNIALS");
                            }//fin del if
                            
                            else if  (cumple >= 1980 && cumple <= 1994){//inicio del if
                                System.out.println("FELICIDADES USTED ES DE LA GENERACION MILLENIALS");
                            }//fin del if
                            
                            else if (cumple >= 1995 && cumple <= 2012){//inicio del if
                                System.out.println("FELICIDADES USTED ES DE LA GENERACION 'Z'");
                            }//fin del if
                            
                            else if (cumple >=2013 && cumple <= 2025){//inicio del else if
                                System.out.println("FELICIDADES USTED ES DE LA GENERACION ALPHA");
                            }//fin del else if
                            
                            else {
                                System.out.println("SU AÑO NO PUEDE SER EVALUDO");
                            }
                            break;
                        default: 
                            System.out.println("MUCHAS GRACIAS POR UTILIZAR EL PROGRAMA");
                            sal=false;
                                break;
                    }//fin del switch
                }//fin del while
        
    }//fin del main
    
}//fin del class
